<?php

namespace App\Interfaces\Job;

interface HasOwner
{
    //
}
