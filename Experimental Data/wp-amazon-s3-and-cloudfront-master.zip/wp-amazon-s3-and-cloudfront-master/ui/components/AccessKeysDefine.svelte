<script>
	export let provider;
</script>

<p>{@html provider.define_access_keys_desc}</p>

<pre>{provider.define_access_keys_example}</pre>
