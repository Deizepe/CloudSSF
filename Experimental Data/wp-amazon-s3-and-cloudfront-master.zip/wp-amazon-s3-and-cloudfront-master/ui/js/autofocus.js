/**
 * A simple action that focuses the supplied HTML node.
 *
 * @param {Object} node
 */
export function autofocus( node ) {
	node.focus();
}