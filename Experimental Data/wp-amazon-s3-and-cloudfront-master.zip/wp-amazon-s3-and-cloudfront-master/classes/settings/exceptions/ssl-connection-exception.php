<?php

namespace DeliciousBrains\WP_Offload_Media\Settings\Exceptions;

class Ssl_Connection_Exception extends Domain_Check_Exception {
}
