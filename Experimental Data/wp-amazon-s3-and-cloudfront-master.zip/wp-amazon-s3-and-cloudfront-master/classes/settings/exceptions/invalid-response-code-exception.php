<?php

namespace DeliciousBrains\WP_Offload_Media\Settings\Exceptions;

class Invalid_Response_Code_Exception extends Domain_Check_Exception {
}
