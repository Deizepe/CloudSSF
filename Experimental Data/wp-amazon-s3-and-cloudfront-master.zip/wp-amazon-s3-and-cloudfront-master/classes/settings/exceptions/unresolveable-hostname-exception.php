<?php

namespace DeliciousBrains\WP_Offload_Media\Settings\Exceptions;

class Unresolveable_Hostname_Exception extends Domain_Check_Exception {
}
