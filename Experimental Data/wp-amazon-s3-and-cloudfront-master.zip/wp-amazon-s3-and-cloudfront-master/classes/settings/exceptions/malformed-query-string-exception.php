<?php

namespace DeliciousBrains\WP_Offload_Media\Settings\Exceptions;

class Malformed_Query_String_Exception extends Domain_Check_Exception {
}
