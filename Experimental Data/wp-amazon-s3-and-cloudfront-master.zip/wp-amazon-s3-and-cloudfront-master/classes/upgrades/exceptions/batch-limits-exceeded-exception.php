<?php

namespace DeliciousBrains\WP_Offload_Media\Upgrades\Exceptions;

class Batch_Limits_Exceeded_Exception extends \Exception {
}
