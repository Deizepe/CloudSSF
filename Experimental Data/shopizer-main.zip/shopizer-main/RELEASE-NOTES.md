Changes in version 3.2.3


Functionality

Enabling ProductPriceApi



