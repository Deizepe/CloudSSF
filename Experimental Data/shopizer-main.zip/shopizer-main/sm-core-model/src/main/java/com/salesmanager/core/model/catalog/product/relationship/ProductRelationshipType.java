package com.salesmanager.core.model.catalog.product.relationship;

public enum ProductRelationshipType {
	
	FEATURED_ITEM, RELATED_ITEM, BUNDLED_ITEM

}
