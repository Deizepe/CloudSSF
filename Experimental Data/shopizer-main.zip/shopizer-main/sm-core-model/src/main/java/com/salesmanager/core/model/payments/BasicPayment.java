package com.salesmanager.core.model.payments;


/**
 * When the user performs a payment using money order or cheque
 * @author Carl Samson
 *
 */
public class BasicPayment extends Payment {

}
