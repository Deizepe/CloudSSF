package com.salesmanager.core.model.catalog.product.attribute;

public enum ProductOptionType {
	
	Text, Radio, Select, Checkbox

}
