package com.salesmanager.core.model.catalog.product.price;

public enum ProductPriceType {
	
	ONE_TIME, MONTHLY

}
