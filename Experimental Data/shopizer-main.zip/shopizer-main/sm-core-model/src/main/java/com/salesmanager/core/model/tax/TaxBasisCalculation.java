package com.salesmanager.core.model.tax;

public enum TaxBasisCalculation {
	
	STOREADDRESS, SHIPPINGADDRESS, BILLINGADDRESS

}
