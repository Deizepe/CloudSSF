package com.salesmanager.core.model.order;

public enum OrderChannel {
	
	ONLINE, API

}
