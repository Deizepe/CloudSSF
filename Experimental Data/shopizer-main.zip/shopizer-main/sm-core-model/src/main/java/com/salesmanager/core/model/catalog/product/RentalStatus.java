package com.salesmanager.core.model.catalog.product;

public enum RentalStatus {
	
	RENTED, AVAILABLE

}
