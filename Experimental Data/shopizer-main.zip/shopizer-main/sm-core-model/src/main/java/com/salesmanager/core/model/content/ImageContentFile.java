package com.salesmanager.core.model.content;

import java.io.Serializable;

public class ImageContentFile extends InputContentFile implements Serializable {

	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
