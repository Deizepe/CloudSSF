package com.salesmanager.core.model.common;

public enum CriteriaOrderBy {

	
	ASC, DESC
}
