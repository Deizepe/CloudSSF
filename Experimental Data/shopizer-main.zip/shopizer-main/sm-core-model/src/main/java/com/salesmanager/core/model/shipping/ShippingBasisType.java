package com.salesmanager.core.model.shipping;

public enum ShippingBasisType {
	
	BILLING, SHIPPING

}
