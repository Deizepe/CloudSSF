package com.salesmanager.core.model.system.credentials;

public class DbCredentials extends Credentials {

}
