package com.salesmanager.core.model.customer.attribute;

public enum CustomerOptionType {
	
	Text, Radio, Select, Checkbox

}
