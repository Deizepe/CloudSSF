package com.salesmanager.core.model.customer.connection;

import javax.persistence.Entity;

@Deprecated
@Entity
public class UserConnection extends AbstractUserConnectionWithCompositeKey {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


}