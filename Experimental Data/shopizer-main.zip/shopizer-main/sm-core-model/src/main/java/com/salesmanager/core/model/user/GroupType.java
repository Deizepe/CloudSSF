package com.salesmanager.core.model.user;

public enum GroupType {
	
	ADMIN, CUSTOMER

}
