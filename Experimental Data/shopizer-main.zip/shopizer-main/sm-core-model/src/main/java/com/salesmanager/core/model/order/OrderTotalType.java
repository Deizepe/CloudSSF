package com.salesmanager.core.model.order;

public enum OrderTotalType {
	
	SHIPPING, HANDLING, TAX, PRODUCT, SUBTOTAL, TOTAL, CREDIT, REFUND

}
