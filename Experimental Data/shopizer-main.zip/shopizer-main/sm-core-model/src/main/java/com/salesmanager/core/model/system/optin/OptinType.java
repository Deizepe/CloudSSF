package com.salesmanager.core.model.system.optin;

public enum OptinType {
	
	NEWSLETTER, PROMOTIONS

}
