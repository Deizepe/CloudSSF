package com.salesmanager.core.model.order;


/**
 * Implementation of rebates calculated used in the ordertotal calculation
 * engine
 * @author carlsamson
 *
 */
public class RebatesOrderTotalVariation extends OrderTotalVariation {

}
