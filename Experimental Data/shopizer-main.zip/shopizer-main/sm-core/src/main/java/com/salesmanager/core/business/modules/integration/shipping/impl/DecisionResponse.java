package com.salesmanager.core.business.modules.integration.shipping.impl;

public class DecisionResponse {
	
	private String moduleName;
	private String customPrice;

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public String getCustomPrice() {
		return customPrice;
	}

	public void setCustomPrice(String customPrice) {
		this.customPrice = customPrice;
	}

}
