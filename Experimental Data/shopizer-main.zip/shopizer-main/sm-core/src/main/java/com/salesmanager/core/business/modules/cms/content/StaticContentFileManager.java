/**
 * 
 */
package com.salesmanager.core.business.modules.cms.content;

/**
 * @author Umesh Awasthi
 *
 */
public abstract class StaticContentFileManager
    implements ContentAssetsManager {

  /**
   * 
   */
  private static final long serialVersionUID = 1L;

}
