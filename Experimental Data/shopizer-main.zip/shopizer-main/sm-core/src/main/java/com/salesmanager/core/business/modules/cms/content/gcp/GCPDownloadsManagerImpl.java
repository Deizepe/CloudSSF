package com.salesmanager.core.business.modules.cms.content.gcp;

import org.springframework.stereotype.Component;

@Component("gcpDownloadsManager")
public class GCPDownloadsManagerImpl extends GCPStaticContentAssetsManagerImpl {
    private static final long serialVersionUID = 1L;

} 