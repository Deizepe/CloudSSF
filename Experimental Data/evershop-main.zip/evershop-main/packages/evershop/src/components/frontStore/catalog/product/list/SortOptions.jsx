const options = [
  { code: 'price', name: 'Price' },
  { code: 'name', name: 'Name' }
];

export default options;
