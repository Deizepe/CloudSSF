<?php

namespace Laraerp\Http\Requests;

class NotaFiscalUploadRequest extends Request
{

    /**
     * Get the validation rules
     *
     * @return array
     */
    public function rules()
    {
        return [];
    }

}
