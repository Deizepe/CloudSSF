<?php

namespace Laraerp\Contracts\Repositories;

use Laraerp\Contracts\RepositoryInterface;

interface UnidadeMedidaRepository extends RepositoryInterface
{

}