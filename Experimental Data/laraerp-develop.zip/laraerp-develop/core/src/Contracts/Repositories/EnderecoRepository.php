<?php

namespace Laraerp\Contracts\Repositories;

use Laraerp\Contracts\RepositoryInterface;

interface EnderecoRepository extends RepositoryInterface
{

}